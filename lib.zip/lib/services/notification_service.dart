import 'dart:async';
import 'dart:convert';
import 'package:chelyabinsk_quest/providers/auth_provider.dart';
import 'package:chelyabinsk_quest/providers/team_provider.dart';
import 'package:chelyabinsk_quest/screens/completion_screen.dart';
import 'package:chelyabinsk_quest/screens/library_info_screen.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/material.dart';
import 'package:chelyabinsk_quest/main.dart';
import 'package:chelyabinsk_quest/providers/quest_provider.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  // Добавляем StreamController для обработки нажатий на уведомления
  static final StreamController<Map<String, dynamic>>
      _notificationStreamController =
      StreamController<Map<String, dynamic>>.broadcast();

  // Публичный поток для прослушивания нажатий на уведомления
  static Stream<Map<String, dynamic>> get onNotificationTap =>
      _notificationStreamController.stream;

  static final SupabaseClient _supabase = Supabase.instance.client;

  static bool appInForeground = true;
  static bool _initialized = false;
  static Timer? _checkTimer;
  static final Map<String, DateTime> _lastNotificationTimes = {};

  static void handleNotificationTap(Map<String, dynamic> payload) {
    if (payload['type'] == 'team_invitation') {
      _showInvitationDialog(
        teamId: payload['team_id'],
        teamName: payload['team_name'],
        inviterUsername: payload['inviter_username'],
        invitationId: payload['invitation_id'],
      );
    }
  }

  static Future<void> init() async {
    if (_initialized) return;

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const LinuxInitializationSettings linuxSettings =
        LinuxInitializationSettings(
      defaultActionName: 'Открыть уведомление',
    );

    final InitializationSettings settings = InitializationSettings(
      android: androidSettings,
      linux: linuxSettings,
    );

    await _notificationsPlugin.initialize(
      settings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        debugPrint("📲 Notification tapped: payload=${response.payload}");

        if (response.payload == null) return;

        try {
          final payload = jsonDecode(response.payload!) as Map<String, dynamic>;
          _notificationStreamController.add(payload);
          handleNotificationTap(payload);
        } catch (e) {
          debugPrint("❌ Error handling notification: $e");
          final context = navigatorKey.currentContext;
          if (context != null && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Ошибка: ${e.toString()}')),
            );
          }
        }
      },
    );

    _initialized = true;
    debugPrint("✅ Notifications initialized");
  }

  static void startCheckingInvitations(String userId) {
    _checkTimer?.cancel(); // Отменяем предыдущий таймер, если он был
    _checkTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      _checkForNewInvitations(userId);
    });
  }

  static void stopChecking() {
    _checkTimer?.cancel();
    _checkTimer = null;
    debugPrint("✅ Notification checking stopped");
  }

  static Future<void> _checkForNewInvitations(String userId) async {
    try {
      final response = await _supabase
          .from('team_invitations')
          .select()
          .eq('invitee_id', userId)
          .eq('status', 'pending')
          .order('created_at', ascending: false)
          .limit(1);

      if (response.isNotEmpty) {
        final invitation = response.first;
        await _showInvitationNotification(invitation);
      }
    } catch (e) {
      debugPrint('Ошибка проверки приглашений: $e');
    }
  }

  static Future<void> _showInvitationNotification(
      Map<String, dynamic> invitation) async {
    if (!_initialized) await init();

    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'team_invitations',
      'Приглашения в команды',
      importance: Importance.high,
      priority: Priority.high,
    );

    const LinuxNotificationDetails linuxDetails = LinuxNotificationDetails(
      urgency: LinuxNotificationUrgency.normal,
    );

    final payload = {
      'type': 'team_invitation',
      'team_id': invitation['team_id'],
      'team_name': invitation['team_name'],
      'inviter_username': invitation['inviter_username'],
      'invitation_id': invitation['id'],
    };

    await _notificationsPlugin.show(
      invitation['id'].hashCode,
      'Приглашение в команду',
      '${invitation['inviter_username']} приглашает вас в команду ${invitation['team_name']}',
      const NotificationDetails(
        android: androidDetails,
        linux: linuxDetails,
      ),
      payload: jsonEncode(payload),
    );
  }

  static void _handleNotificationTap(Map<String, dynamic> payload) {
    final context = navigatorKey.currentContext;
    if (context == null || payload['type'] != 'team_invitation') return;

    _showInvitationDialog(
      teamId: payload['team_id'],
      teamName: payload['team_name'],
      inviterUsername: payload['inviter_username'],
      invitationId: payload['invitation_id'],
    );
  }

  static void _showInvitationDialog({
    required String teamId,
    required String teamName,
    required String inviterUsername,
    required String invitationId,
  }) {
    final context = navigatorKey.currentContext;
    if (context == null) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Приглашение в команду'),
        content: Text('$inviterUsername приглашает вас в команду $teamName'),
        actions: [
          TextButton(
            onPressed: () =>
                _respondToInvitation(context, invitationId, teamId, false),
            child: const Text('Отклонить'),
          ),
          TextButton(
            onPressed: () =>
                _respondToInvitation(context, invitationId, teamId, true),
            child: const Text('Принять'),
          ),
        ],
      ),
    );
  }

  static void _respondToInvitation(
    BuildContext context,
    String invitationId,
    String teamId,
    bool accept,
  ) {
    Navigator.pop(context);
    Provider.of<TeamProvider>(context, listen: false).respondToInvitation(
      invitationId: invitationId,
      accept: accept,
      teamId: teamId,
      userId: Provider.of<AuthProvider>(context, listen: false).currentUser!.id,
    );
  }

  static Future<void> sendTeamInvitation({
    required String teamId,
    required String teamName,
    required String inviterId,
    required String inviterUsername,
    required String inviteeId,
    required String invitationId,
  }) async {
    try {
      // Сохраняем уведомление в базу
      await _supabase.from('notifications').insert({
        'user_id': inviteeId,
        'title': 'Приглашение в команду',
        'message': '$inviterUsername приглашает вас в команду $teamName',
        'payload': {
          'type': 'team_invitation',
          'team_id': teamId,
          'team_name': teamName,
          'inviter_id': inviterId,
          'inviter_username': inviterUsername,
          'invitation_id': invitationId,
        },
      });

      debugPrint("✅ Приглашение отправлено (ID: $invitationId)");
    } catch (e) {
      debugPrint('❌ Ошибка отправки: ${e.toString()}');
      rethrow;
    }
  }

  static Future<void> sendTeamInvitationNotification({
    required String teamId,
    required String teamName,
    required String inviterId,
    required String inviterUsername,
    required String inviteeId,
    required String invitationId,
  }) async {
    try {
      // Сохраняем уведомление в базу данных для получателя
      await _supabase.from('user_notifications').insert({
        'user_id': inviteeId,
        'title': 'Приглашение в команду',
        'message': '$inviterUsername приглашает вас в команду $teamName',
        'payload': {
          'type': 'team_invitation',
          'team_id': teamId,
          'team_name': teamName,
          'inviter_username': inviterUsername,
          'invitation_id': invitationId,
        },
        'created_at': DateTime.now().toIso8601String(),
        'read': false,
      });

      // Отправляем push-уведомление через Supabase Realtime
      final channel = _supabase.channel('notifications_$inviteeId');

      await channel.subscribe();
      await _supabase.from('notifications').insert({
        'user_id': inviteeId,
        'type': 'team_invitation',
        'data': {
          'title': 'Приглашение в команду',
          'body': '$inviterUsername приглашает вас в команду $teamName',
          'team_id': teamId,
          'team_name': teamName,
          'inviter_username': inviterUsername,
          'invitation_id': invitationId,
        },
      });

      debugPrint("✅ Приглашение отправлено получателю (ID: $invitationId)");
    } catch (e) {
      debugPrint('❌ Ошибка отправки приглашения: $e');
      rethrow;
    }
  }

  // Инициализация слушателя уведомлений
  static void initNotificationListener(String userId) {
    final channel = _supabase.channel('user_${userId}_notifications');

    channel
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (payload) {
            final notification = payload.newRecord;
            if (notification['user_id'] == userId) {
              showLocalNotification(
                title: notification['title'],
                body: notification['message'],
                payload: notification['payload'],
              );
            }
          },
        )
        .subscribe();
  }

  static Future<void> showLocalNotification({
    required String title,
    required String body,
    required dynamic payload,
  }) async {
    if (!_initialized) await init();

    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'team_invitations',
      'Приглашения в команды',
      importance: Importance.high,
      priority: Priority.high,
    );

    const LinuxNotificationDetails linuxDetails = LinuxNotificationDetails(
      urgency: LinuxNotificationUrgency.normal,
    );

    await _notificationsPlugin.show(
      payload['invitation_id'].hashCode,
      title,
      body,
      const NotificationDetails(
        android: androidDetails,
        linux: linuxDetails,
      ),
      payload: jsonEncode(payload),
    );
  }

  static Future<void> _showNotification({
    required String title,
    required String body,
    required Map<String, dynamic> payload,
  }) async {
    if (!_initialized) await init();

    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'team_invitations',
      'Team Invitations',
      importance: Importance.high,
      priority: Priority.high,
    );

    const LinuxNotificationDetails linuxDetails = LinuxNotificationDetails(
      urgency: LinuxNotificationUrgency.normal,
    );

    final NotificationDetails details = NotificationDetails(
      android: androidDetails,
      linux: linuxDetails,
    );

    await _notificationsPlugin.show(
      payload['invitation_id'].hashCode,
      title,
      body,
      details,
      payload: jsonEncode(payload),
    );
  }

  // Остальные методы остаются без изменений
  static Future<void> showQuestNotification({
    required String title,
    required String message,
    required String questId,
    required String locationId,
  }) async {
    if (!_initialized) await init();

    final key = '$questId-$locationId';
    final lastTime = _lastNotificationTimes[key];
    if (lastTime != null &&
        DateTime.now().difference(lastTime) < const Duration(minutes: 5)) {
      debugPrint("⏳ Notification for $key was shown recently, skipping");
      return;
    }

    debugPrint("📢 Showing notification: $title - $message");

    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'quest_channel',
      'Quest Notifications',
      channelDescription: 'Notifications for quest updates',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
    );

    const LinuxNotificationDetails linuxDetails = LinuxNotificationDetails(
      urgency: LinuxNotificationUrgency.normal,
    );

    final NotificationDetails details = NotificationDetails(
      android: androidDetails,
      linux: linuxDetails,
    );

    final String payload = '$locationId,$questId';

    await _notificationsPlugin.show(
      key.hashCode,
      title,
      message,
      details,
      payload: payload,
    );

    _lastNotificationTimes[key] = DateTime.now();
    debugPrint("✅ Notification shown with payload: $payload");
  }

  static Future<void> showAllQuestsCompletedNotification() async {
    if (!_initialized) await init();

    debugPrint("📢 Showing all quests completed notification");

    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'quest_channel',
      'Quest Notifications',
      channelDescription: 'Notifications for quest updates',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
    );

    const LinuxNotificationDetails linuxDetails = LinuxNotificationDetails(
      urgency: LinuxNotificationUrgency.normal,
    );

    final NotificationDetails details = NotificationDetails(
      android: androidDetails,
      linux: linuxDetails,
    );

    await _notificationsPlugin.show(
      'all_quests'.hashCode,
      'Поздравляем!',
      'Вы завершили все квесты!',
      details,
      payload: 'all_quests_completed',
    );

    debugPrint("✅ All quests completed notification shown");
  }
}
