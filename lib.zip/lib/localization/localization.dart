import 'package:chelyabinsk_quest/localization/app_localizations.dart';
import 'package:flutter/material.dart';

extension StringLocalization on String {
  String tr(BuildContext context) {
    return AppLocalizations.of(context)!.translate(this) ?? this;
  }
}
